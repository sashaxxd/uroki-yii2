<?php
echo 'admin';