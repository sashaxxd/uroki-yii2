<?=$hi?>
<br>
<?php
foreach ($names as $names)
{
    echo $names.'<br>';
}
?>
<br>
<?php
echo $id;
