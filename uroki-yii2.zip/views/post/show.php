<?php //$this->title = 'Одна статья' Лучше через контроллер?>
<h1>Вид для show</h1>


<?php //Debug($cats)?>
<?php  echo count($cats->products) ?>
<?php //Debug($cats)?>




<button class="btn btn-success" id="btn">Кликнуть</button>

<?php
/*
 * Подключаем скрипт для конкретного представления
 * (вида) функцией yii2 registerJsFile(подключает файл скрипта)
 * второй параметр массив(в скобках функции указывает на зависимость от jQuery
 */
//Cкрипт использует библиотеку jQuery
// поэтому должен быть подключен выше
// по коду jQuery
//$this->registerJsFile('@web/js/scripts.js', ['depends' => 'yii\web\YiiAsset'])
 ?>
<?php
// Функция registerJs подключает сам код скрипта - обратить внимание на кавычки!!!
// POS_LOAD или POS_READY используем для js - подучить js!!!
//$this->registerJs("$('.container').append('<p>show!!!</p>');", \yii\web\View::POS_LOAD);
/*
 * Функция регистрации css кода
 */
$this->registerCss('.container{background: #ccc;}');

/*
 * Функция регистрации css файла
 */
$this->registerCssFile('@web/css/style2.css');

?>

<?php
// Cпособ подключения для registerJs более удобный вариант
$js = <<<JS
    $('#btn').on('click', function(){
        $.ajax({
            url: 'index.php?r=post/index', //Куда отправляем
            data: {test: 'Пиздец'},  //Данные которые отправляем - переменная test со значением 123
            type: 'POST', // Отправляем методом POST или GET если POST_ом идет проверка yii
            // для поста в шаблоне необходимо вставить мета тег <?= Html::csrfMetaTags() ?>
            success: function(res){ //ответ попадает в переменную res
                console.log(res); //выводим переменную res в консоли
            },
            error: function(){    // В случае ошибки
                alert('Error!');
            }
        });
    });
JS;

$this->registerJs($js);
?>


<?php $this->BeginBlock('block1'); // Создаем дополнительный блок на странице для передачи данных из вида в шаблон?>
   <h1>Заголовок</h1>
<?php $this->endBlock(); ?>

<br>


