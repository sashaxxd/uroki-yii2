//alert('hi');

$('.container').append('<p>show!!!</p>');//Cкрипт использует библиотеку jQuery
// поэтому должен быть подключен выше
// по коду jQuery

