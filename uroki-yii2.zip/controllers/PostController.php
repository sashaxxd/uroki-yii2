<?php
/**
 * User: noutsasha
 * Date: 12.04.2017
 * Time: 15:14
 */

namespace app\controllers;
use app\models\Category;
use Yii;
use app\models\TestForm;


class PostController extends AppController//Одно пространство имен не надо подключать use
{
    //указываем шаблон для всего контроллера
    public  $layout = 'template';

    public function actionIndex()
    {
         if(Yii::$app->request->isAjax)// Если отправлено методом аякс
         {
             // Debug($_POST);// Распечатываем данные с post обчным способом
             Debug(Yii::$app->request->post());// Распечатываем данные с post методом YII
             return'test';

         }
        $model = new TestForm();
        if($model->load(Yii::$app->request->post()))// Если данные загружены в модель
        {
            //Debug($model);die;
            if($model->validate())
            {
                Yii::$app->session->setFlash('sucсess', 'Данные приняты');// Запись в сессию при валидации
                return $this->refresh();// Сбрасываем данные с формы
            }
            else{
                 Yii::$app->session->setFlash('error', 'Ошибка');
                //return $this->refresh();// тут не будем сбрасывать данные что бы можно было поправить
            }

        }

        return $this->render('test',[
            'model' => $model,
        ]);
    }
    public  function  actionShow()
    {
        $this->view->title = 'Одын одын';// Указываем тайтл для конкретного экшэна
        $this->view->registerMetaTag(['name' => 'keywords', 'content' => 'ключевые слова']);//метод для метатегов
        $this->view->registerMetaTag(['name' => 'description', 'content' => 'описание']);
        //$this->layout = 'template'; указываем шаблон для конкретного экшена

        //$cats = Category::find()->all(); // Все данные из базы в видео объектов
        //$cats = Category::find()->orderBy(['id' => SORT_DESC])->all();//Cортируем по id в обратном
        //$cats = Category::find()->orderBy(['id' => SORT_ASC])->all();//Cортируем по id
        //$cats = Category::find()->asArray()->all(); // Все данные в виде массива (быстрее работает)
        //$cats = Category::find()->asArray()->where('parent = 691')->all();
        //$cats = Category::find()->asArray()->where(['parent' => '691'])->all(); // В виде массива
        //$cats = Category::find()->asArray()->where(['like', 'title', 'запчасти'])->all(); // Запрос для поиска
        //$cats = Category::find()->asArray()->where(['<=', 'id', '695'])->all(); // SELECT * FROM `categories` WHERE `id` <= '695'
        //$cats = Category::find()->asArray()->where('parent = 691')->limit(1)->all();
        //$cats = Category::find()->asArray()->where('parent = 691')->limit(1)->one();//Обязательно ставить лимит даже если one
        //$cats = Category::find()->asArray()->where('parent = 691')->count();//Количестов записей с условием
        //$cats = Category::find()->asArray()->count(); //Кол-во записей всех
        //$cats = Category::findOne(['parent' => '691']);//Другой способ вернуть один объект
        //$cats = Category::findAll(['parent' => '691']);//Другой способ вернуть все объекты
        /*
         * Cпособ самостоятельного построения запросов
         *
         *   $query = "SELECT * FROM categories WHERE title LIKE :search";
         *   $cats = Category::findBySql($query, [':search' => '%pp%'])->all();
         */

        $cats = Category::findOne(694);

        return $this->render('show', compact('cats'));
    }

}