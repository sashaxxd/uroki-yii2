<?php
function Debug($arr)
{
    echo '<pre>'.print_r($arr, true).'</pre>';
}